const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const session = require('express-session');

const app = express();
const PORT = 3000;

// --- SESSION SETUP (before any route!) ---
app.use(session({
  secret: 'my-very-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // true only if using HTTPS
    httpOnly: true
  }
}));

// --- MIDDLEWARE ---
app.use(express.json());
app.use(express.static('public'));

// --- FILE STORAGE SETUP FOR IMAGES ---
const upload = multer({ dest: path.join(__dirname, 'public/images') });

// --- DB FILE PATHS ---
const usersPath = path.join(__dirname, 'db', 'users.json');
const eventsPath = path.join(__dirname, 'db', 'events.json');
const reviewsPath = path.join(__dirname, 'db', 'review.json');
const reservationsPath = path.join(__dirname, 'db', 'reservations.json');

// --- HELPER FUNCTIONS ---
function readJSON(filepath) {
  if (!fs.existsSync(filepath)) return [];
  return JSON.parse(fs.readFileSync(filepath, 'utf-8') || '[]');
}

function writeJSON(filepath, data) {
  fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
}

// ======================
// 🔐 AUTH ROUTES
// ======================

// Register user
app.post('/register', (req, res) => {
  const { email, password } = req.body;
  const users = readJSON(usersPath);
  if (users.find(user => user.email === email)) {
    return res.json({ error: 'Email already registered' });
  }

  users.push({ email, password });
  writeJSON(usersPath, users);
  res.json({ success: true });
});

// Login user
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = readJSON(usersPath);
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    req.session.user = email;
    res.json({ success: true });
  } else {
    res.json({ error: 'Invalid email or password' });
  }
});

// Logout
app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

// ======================
// 📅 EVENT ROUTES (CRUD)
// ======================

// Get all events
app.get('/events', (req, res) => {
  const events = readJSON(eventsPath);
  res.json(events);
});

// Create new event with image
app.post('/events', upload.single('image'), (req, res) => {
  const events = readJSON(eventsPath);
  const { title, description } = req.body;

  const newEvent = {
    id: Date.now().toString(),
    title,
    description,
    images: req.file ? [`images/${req.file.filename}`] : []
  };

  events.push(newEvent);
  writeJSON(eventsPath, events);
  res.redirect('/events.html');
});

// Update event
app.put('/events/:id', (req, res) => {
  const events = readJSON(eventsPath);
  const index = events.findIndex(e => e.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Event not found' });

  events[index] = { ...events[index], ...req.body };
  writeJSON(eventsPath, events);
  res.json({ message: 'Event updated', event: events[index] });
});

// Delete event
app.delete('/events/:id', (req, res) => {
  const events = readJSON(eventsPath);
  const updated = events.filter(e => e.id !== req.params.id);
  if (updated.length === events.length) {
    return res.status(404).json({ error: 'Event not found' });
  }

  writeJSON(eventsPath, updated);
  res.json({ message: 'Event deleted' });
});

// ======================
// 💬 REVIEWS
// ======================
app.get('/reviews/:eventId', (req, res) => {
  const reviews = readJSON(reviewsPath);
  const filtered = reviews.filter(r => r.eventId === req.params.eventId);
  res.json(filtered);
});

app.post('/reviews/:eventId', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Login required' });

  const reservations = readJSON(reservationsPath);
  const hasReserved = reservations.some(r => r.user === req.session.user && r.id === req.params.eventId);
  if (!hasReserved) return res.status(403).json({ error: 'You must reserve before reviewing' });

  const reviews = readJSON(reviewsPath);
  reviews.push({
    eventId: req.params.eventId,
    content: req.body.content,
    user: req.session.user,
    timestamp: new Date().toISOString()
  });

  writeJSON(reviewsPath, reviews);
  res.json({ success: true });
});

// ======================
// 🎟️ RESERVATIONS
// ======================

// Make a reservation
app.post('/reserve/:id', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });

  const events = readJSON(eventsPath);
  const reservations = readJSON(reservationsPath);
  const event = events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  // Prevent duplicate reservation
  if (reservations.some(r => r.user === req.session.user && r.id === req.params.id)) {
    return res.json({ success: false, error: 'Already reserved' });
  }

  reservations.push({ ...event, user: req.session.user });
  writeJSON(reservationsPath, reservations);
  res.json({ success: true });
});

// Cancel reservation
app.delete('/cancel-reservation/:id', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });

  const reservations = readJSON(reservationsPath);
  const updated = reservations.filter(r => !(r.user === req.session.user && r.id === req.params.id));
  writeJSON(reservationsPath, updated);
  res.json({ success: true });
});

// Get my reservations
app.get('/my-reservations', (req, res) => {
  if (!req.session.user) return res.status(401).json([]);

  const reservations = readJSON(reservationsPath);
  const mine = reservations.filter(r => r.user === req.session.user);
  res.json(mine);
});

// ======================
// ✅ Start Server
// ======================
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
