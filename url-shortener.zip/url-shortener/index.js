const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());

const dbPath = path.join(__dirname, 'db', 'urls.json');

// Load DB or create it if not exists
function loadDB() {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}));
  }
  const data = fs.readFileSync(dbPath);
  return JSON.parse(data);
}

function saveDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

// POST /shorten - create a short URL
app.post('/shorten', (req, res) => {
  const { originalUrl } = req.body;
  if (!originalUrl) return res.status(400).json({ error: 'originalUrl is required' });

  const id = Math.random().toString(36).substring(2, 8);
  const db = loadDB();
  db[id] = originalUrl;
  saveDB(db);

  res.json({ shortUrl: `http://localhost:${PORT}/${id}` });
});

// GET /:id - redirect to original URL
app.get('/:id', (req, res) => {
  const db = loadDB();
  const originalUrl = db[req.params.id];
  if (originalUrl) {
    res.redirect(originalUrl);
  } else {
    res.status(404).send('Short URL not found');
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
